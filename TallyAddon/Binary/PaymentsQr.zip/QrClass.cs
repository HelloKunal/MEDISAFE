﻿using QRCoder;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Media.Imaging;

namespace PaymentsQr
{
    public class QrClass
    {

        public String GenerateQr(String Qrdata,String qrDir,String fileName)
        {
            
             
         if (String.IsNullOrEmpty(Qrdata) || String.IsNullOrEmpty(qrDir) || String.IsNullOrEmpty(fileName))
            {
                return "Error - invalid input";
            }
            if (!System.IO.Directory.Exists(qrDir))
            {
                System.IO.Directory.CreateDirectory(qrDir);
            }
            try
            {
    
                BitmapImage bitmapImage;
                QRCodeGenerator qRCodeGenerator = new QRCodeGenerator();
                QRCodeData qRCodedata = qRCodeGenerator.CreateQrCode(Qrdata.ToString(), QRCodeGenerator.ECCLevel.Q);
                QRCode qrcode = new QRCode(qRCodedata);
                Bitmap bitmap = qrcode.GetGraphic(20);
                using (var memory = new System.IO.MemoryStream())
                {
                    bitmap.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
                    memory.Position = 0;
                    bitmapImage = new BitmapImage();
                    bitmapImage.BeginInit();
                    bitmapImage.StreamSource = memory;
                    bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                    bitmapImage.EndInit();
                }
                if (bitmapImage != null)
                {
                    String img_path = System.IO.Path.Combine(qrDir, fileName+".jpg");
                    BitmapEncoder encoder = new JpegBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(bitmapImage));
                    if (System.IO.File.Exists(img_path))
                    {
                        System.IO.File.Delete(img_path);
                    }
                    using (var Qr_img = new FileStream(img_path, FileMode.Create))
                    {
                        encoder.Save(Qr_img);
                    }
                }
                return "Qr generated successfully"; 
            }catch(Exception ex)
            {
                return "Error -"+ ex.Message;
            }


        }









    }

}
